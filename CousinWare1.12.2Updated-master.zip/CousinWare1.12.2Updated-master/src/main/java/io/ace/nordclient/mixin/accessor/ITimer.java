package io.ace.nordclient.mixin.accessor;

public interface ITimer {

    void setTickLength(float tickLength);

    float getTickLength();
}
