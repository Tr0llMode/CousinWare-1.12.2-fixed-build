package io.ace.nordclient.hacks.render;

import io.ace.nordclient.hacks.Hack;

public class InfiniteChatlength extends Hack {

    public InfiniteChatlength() {
        super("InfiniteChatlength", Category.RENDER, 8711642);
    }

}
