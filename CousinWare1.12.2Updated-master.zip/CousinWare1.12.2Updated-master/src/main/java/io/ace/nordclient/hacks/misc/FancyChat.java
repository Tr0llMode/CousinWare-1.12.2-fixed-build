package io.ace.nordclient.hacks.misc;

import io.ace.nordclient.hacks.Hack;

public class FancyChat extends Hack {

    public FancyChat() {
        super("FancyChat", Category.MISC, "Makes Chat Use Custom Font!", 14007024);
    }

}
