package io.ace.nordclient.utilz;

public class FriendUtil {

    /**
     * @author Ace________/Ace_#1233
     */

    String name;
    public FriendUtil(String n){
        name = n;
    }

    public String getName(){
        return name;
    }
}


