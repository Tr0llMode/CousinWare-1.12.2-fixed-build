package io.ace.nordclient.event;

public class PlayerJumpEvent {

}
