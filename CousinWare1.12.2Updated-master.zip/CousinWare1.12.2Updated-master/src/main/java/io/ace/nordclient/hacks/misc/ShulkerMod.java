package io.ace.nordclient.hacks.misc;

import io.ace.nordclient.hacks.Hack;

/**
 * @author Ace________/Ace_#1233
 */

public class ShulkerMod extends Hack {

    public ShulkerMod() {
        super("ShulkerMod", Category.MISC, "Allows the player to put shulkers in shulkers(Must Be In Creative)", 2568772);
    }
    //
}
