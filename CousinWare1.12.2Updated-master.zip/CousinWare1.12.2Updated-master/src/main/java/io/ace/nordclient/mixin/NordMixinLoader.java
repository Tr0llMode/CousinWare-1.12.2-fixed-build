package io.ace.nordclient.mixin;

import io.ace.nordclient.CousinWare;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;

import java.util.Map;

public class NordMixinLoader implements IFMLLoadingPlugin {

    private static boolean isObfuscatedEnvironment = false;

    public NordMixinLoader() {
        CousinWare.log.info("CousinWare mixin initialized");
        CousinWare.log.info("Mixins Created By Ace");
        MixinBootstrap.init();
        Mixins.addConfiguration("mixin.nordclient.json");
        MixinEnvironment.getDefaultEnvironment().setObfuscationContext("searge");

    }

    @Override
    public String[] getASMTransformerClass() {
        return new String[0];
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data) {
        isObfuscatedEnvironment = (boolean) (Boolean) data.get("runtimeDeobfuscationEnabled");
    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}
