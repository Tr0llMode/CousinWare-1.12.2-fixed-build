package io.ace.nordclient.mixin.accessor;

public interface IEntity {

    boolean getIsInWeb();

    boolean isInPortal();
}
