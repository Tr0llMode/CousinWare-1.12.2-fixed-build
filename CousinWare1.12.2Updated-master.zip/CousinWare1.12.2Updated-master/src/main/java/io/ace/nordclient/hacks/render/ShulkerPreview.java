package io.ace.nordclient.hacks.render;

import io.ace.nordclient.hacks.Hack;

public class ShulkerPreview extends Hack {

    public ShulkerPreview() {
        super("ShulkerPreview", Category.RENDER, 11189657);
    }
}
