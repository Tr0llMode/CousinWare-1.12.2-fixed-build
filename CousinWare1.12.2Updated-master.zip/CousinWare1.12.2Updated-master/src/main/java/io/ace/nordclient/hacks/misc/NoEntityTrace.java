package io.ace.nordclient.hacks.misc;

import io.ace.nordclient.hacks.Hack;

public class NoEntityTrace extends Hack {

    public NoEntityTrace() {
        super("NoEntityTrace", Category.MISC, 12118328);
    }
}
