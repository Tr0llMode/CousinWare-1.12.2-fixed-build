package io.ace.nordclient.event;

public class EventPlayerResetBlockRemoving extends EventCancellable {
}