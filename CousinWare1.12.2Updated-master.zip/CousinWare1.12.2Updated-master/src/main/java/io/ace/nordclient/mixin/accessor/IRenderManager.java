package io.ace.nordclient.mixin.accessor;

public interface IRenderManager {

    double getRenderPosX();

    double getRenderPosY();

    double getRenderPosZ();
}
