# CousinWare

CousinWare is the client I've been working on for about 9 months. It was originally a client made for my friends but seeing as how I'm leaving the community (and already have), thought I'd make it public.

## FAQ

| Question | Answer |
| -------- | ------ |
| Is this a rat? | No, why would I do that, I'm leaving the community. But if you don't belive me, you have commit history for the past 9 months. |
| Is this client the leaked private client that will change pvp for history? | No, but there are some unique things so please take a look around. Personally my favorite is the block placements I've added, as they're able to bypass most strict NCP servers. They also work better than any other client on Oldfag which has a really strict NCP config. (Okay sorry about bragging about the placements) |
| Is this client going to be updated? | Kinda, when I'm really bored I might open up IntelliJ to mess with something. If I do, I'll push the changes. |
| What if the server updates to 1.16? | I've also uploaded [my 1.16 port](https://github.com/Ace8Underscore/CousinWare1.16.4) which is missing a lot of stuff, but you can continue off of that if you wish. |

## Special thanks

Thanks to the following people for helping me with issues on this project or on my journey to this point:

- [John200410](https://github.com/John200410)
- [Fleyr_](https://github.com/xFleyr)
- [Elementars](https://github.com/Elementars)

And an extra special thanks to the following CousinWare users for their support:

- Cacti
- Halee
- Chae
- L1GH7ER 
- Nicky
- Reckinq
- Kam
- Sohai
- Bong
- Input
- Kildrio
- Takeouts

## Credits

- **Hero code** - for the settings and the file manager
- **Memeszz** - for letting me use and modify the aurora gui
- **Osiris dev** - for the command system



Cant remember whats new but its got pop chams, choruslag, and some other things i cant remember 
